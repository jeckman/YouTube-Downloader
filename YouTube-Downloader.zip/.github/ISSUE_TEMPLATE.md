<!--

Do you want to ask a question? Are you looking for support? The Gitter chat might be a better place for getting support: https://gitter.im/jeckman-YouTube-Downloader/Lobby

-->

### Description

[Description of the issue]

### Steps to Reproduce

Please include the direct url to the YouTube video.

1. [First Step]
2. [Second Step]
3. [and so on...]

**Expected behavior:** [What you expect to happen]

**Actual behavior:** [What actually happens]

### Version

Please include the version of YouTube-Downloader you are running. You can get this information from the footer in the web interface.

### Additional Information

Any additional information, configuration, server OS and what version of the OS you're running or data that might be necessary to reproduce the issue.
